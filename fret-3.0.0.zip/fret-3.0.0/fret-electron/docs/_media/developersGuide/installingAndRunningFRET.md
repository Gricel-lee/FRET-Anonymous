### Important note for developers

* 'npm start' runs the Fret Electron Application built in the 'npm run fret-install' step. If you make changes to the source code or the npm packages, do an 'npm run build' to include your changes before running FRET ('npm start').  Do an 'npm run bstart' to combine both the build step and start step.
