## [in,only,null,order] Pattern
_No image yet_
 * **FT Semantics**: Under construction.
 * **PT Semantics**: Under construction.
 * **Description**: We are working on formalizing this template. In the meanwhile, you can see its intended meaning in the diagram provided.
   > **_Example_**: _in PackageInstallation, only when lowLevel > highLevel shall the system    first  increment the lowLevel variable and then  decrement the highLevel variable_   
***
