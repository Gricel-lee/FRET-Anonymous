## [before,regular,after,satisfaction] Pattern
_No image yet_
 * **FT Semantics**: No meaning assigned.
 * **PT Semantics**: No meaning assigned.
 * **Description**: Your requirement matches our patterns of meaningless requirements.
   > **_Example_**: _before PackageInstallation,  when lowLevel > highLevel,the system shall after 10 secs satisfy (indicationLight = orange)_   
***
[[Home]](../semantics.md)