## [onlyAfter,null,always,not_order] Pattern
_No image yet_
 * **FT Semantics**: No meaning assigned.
 * **PT Semantics**: No meaning assigned.
 * **Description**: Your requirement matches our patterns of meaningless requirements.
   > **_Example_**: _only after PackageInstallation,   shall the system  always not first  increment the lowLevel variable and then  decrement the highLevel variable_   
***
[[Home]](../semantics.md)