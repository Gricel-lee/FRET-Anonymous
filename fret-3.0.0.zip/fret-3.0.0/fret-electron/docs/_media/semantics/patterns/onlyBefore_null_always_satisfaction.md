## [onlyBefore,null,always,satisfaction] Pattern
_No image yet_
 * **FT Semantics**: Under construction.
 * **PT Semantics**: Under construction.
 * **Description**: We are working on formalizing this template. In the meanwhile, you can see its intended meaning in the diagram provided.
   > **_Example_**: _only before PackageInstallation,   shall the system  always satisfy (indicationLight = orange)_   
***
[[Home]](../semantics.md)