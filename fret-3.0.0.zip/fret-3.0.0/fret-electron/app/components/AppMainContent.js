// Copyright © 2025, United States Government, as represented by the Administrator of the National Aeronautics and Space Administration. All rights reserved.
//
// The “FRET : Formal Requirements Elicitation Tool - Version 3.0” software is licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0.
//
// Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.
// @flow
import React from 'react';
import PropTypes from 'prop-types';
import Dashboard from './Dashboard';
import SortableTable from './SortableTable';
import AnalysisTabs from './AnalysisTabs';
import Settings from './Settings';
import Info from './Info';
import Grammar from './Grammar';

import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';

class AppMainContent extends React.Component {

  render() {
    const { content, selectedProject, listOfProjects, requirements }  = this.props
    if (content === 'dashboard')
      return <Dashboard selectedProject={selectedProject} requirements={requirements} listOfProjects={listOfProjects}/>
    if (content === 'requirements')
      return <SortableTable selectedProject={selectedProject} listOfProjects={listOfProjects} requirements={requirements}/>
      if (content === 'analysis')
        return <AnalysisTabs selectedProject={selectedProject} listOfProjects={listOfProjects}/>
    if (content === 'settings')
      return <Settings />
    if (content === 'info')
      return <Info />
    if (content === 'grammar')
      return <Grammar />
  }
}

AppMainContent.propTypes = {
  content: PropTypes.string.isRequired,
  selectedProject: PropTypes.string.isRequired,
  listOfProjects: PropTypes.array.isRequired,
  requirements: PropTypes.array.isRequired
}

export default AppMainContent;
